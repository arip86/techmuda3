
  <footer class="footer text-faded text-center py-5">
    <div class="container">
      <p class="m-0 small">Copyright &copy; Your Website 2019</p>
    </div>
  </footer><?php /**PATH C:\xampp\htdocs\wo\resources\views/layouts/footer.blade.php ENDPATH**/ ?>