 
<?php $__env->startSection('content'); ?>

<div class="card o-hidden border-0 shadow-lg my-5">
  <div class="card-body p-0">
    <!-- Nested Row within Card Body -->
    <div class="row">
      <div class="col-lg-12">
        <div class="p-5">
          <div class="text-center">
            <h1 class="h4 text-gray-900 mb-4">
            Form Paket</h1>
          </div>

          <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <form class="user" method="POST" action="<?php echo e(route('paket.update',$d->id)); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>


            <div class="form-group row">

              <div class="col-sm-6 mb-3 mb-sm-0">
                <input type="text" class="form-control form-control-user" placeholder="Nama Lengkap" name="nama" value="<?php echo e($d->nama); ?>">                   
              </div>

              <div class="col-sm-6 mb-3 mb-sm-0">
                <input type="text" class="form-control form-control-user" placeholder="Catering" name="catering" value="<?php echo e($d->catering); ?>">                   
              </div>


            </div>

            <div class="form-group row">

              <div class="col-sm-6 mb-3 mb-sm-0">
                <input type="text" class="form-control form-control-user" placeholder="Dekorasi" name="dekorasi" value="<?php echo e($d->dekorasi); ?>">                   
              </div>

              <div class="col-sm-6 mb-3 mb-sm-0">
                <input type="text" class="form-control form-control-user" placeholder="Rias" name="rias" value="<?php echo e($d->rias); ?>">                   
              </div>


            </div>

            <div class="form-group row">

              <div class="col-sm-6 mb-3 mb-sm-0">
                <input type="text" class="form-control form-control-user" placeholder="Tempat" name="tempat" value="<?php echo e($d->tempat); ?>">                   
              </div>

              <div class="col-sm-6 mb-3 mb-sm-0">
                <input type="text" class="form-control form-control-user" placeholder="Harga" name="harga" value="<?php echo e($d->harga); ?>">                   
              </div>


            </div>





            <div class="form-group">
              <div class="col-sm-6 mb-3 mb-sm-0">
                <label>Foto : 
                  <input type="file" class="form-control-file" name="foto" value="<?php echo e($d->foto); ?>">
                </label>
              </div>                  
            </div>

            <div class="form-group">
              <?php
                    //ambil dari owner = select * from owner
              $rs = App\Owner::all();
              ?>
              <select name="owner_id" class="form-control">
                <option value="">-- Pilih Owner --</option>
                <?php $__currentLoopData = $rs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <?php
                    //edit data lama
                $sel = ($d->owner_id == $row->id) ? 'selected' : '';  
                ?>




                <option value="<?php echo e($row->id); ?>"<?php echo e($sel); ?>><?php echo e($row->nama); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>

            <button type="submit" class="btn btn-primary">Ubah</button>

          </form>

          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\wo\resources\views/paket/update.blade.php ENDPATH**/ ?>