
<h1 class="site-heading text-center text-white d-none d-lg-block">
    <span class="site-heading-upper text-primary mb-3">Welcome To</span>
    <span class="site-heading-lower">Wedding Organizer</span>
  </h1>
<?php /**PATH C:\xampp\htdocs\wo\resources\views/layouts/topbar.blade.php ENDPATH**/ ?>