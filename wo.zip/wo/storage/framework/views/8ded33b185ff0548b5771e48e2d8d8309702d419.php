<?php $__env->startSection('content'); ?>

<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="card o-hidden border-0 shadow-lg my-5">
  <div class="card-body p-0">
    <!-- Nested Row within Card Body -->
    <div class="row">
      <div class="col-lg-5">
        <br/>
        <br/>
        <center>
        <img src="<?php echo e(asset('img')); ?>/<?php echo e($paket->foto); ?>" width="80%" />
        </center>
      </div>
      <div class="col-lg-7">
        <div class="p-5">
          <div class="text-center">
            <h1 class="h4 text-gray-900 mb-4"><?php echo e($paket->nama); ?></h1>
          </div>
          <form class="user">
            <div class="form-group row">
              <div class="col-sm-6 mb-3 mb-sm-0">
                <label>Catering : </label>
                <input type="text" class="form-control form-control-user" id="exampleFirstName" placeholder="<?php echo e($paket->catering); ?>" disabled="">
              </div>
              <div class="col-sm-6">
                <label>Dekorasi : </label>
                <input type="text" class="form-control form-control-user" id="exampleLastName" placeholder="<?php echo e($paket->dekorasi); ?>" disabled="">
              </div>
            </div>
            <div class="form-group row">
              <div class="col-sm-6 mb-3 mb-sm-0">
                <label>Rias : </label>
                <input type="text" class="form-control form-control-user" id="exampleInputEmail" placeholder="<?php echo e($paket->rias); ?>" disabled="">
              </div>
              <div class="col-sm-6 mb-3 mb-sm-0">
                <label>Nama Owner : </label>
                <input type="text" class="form-control form-control-user" id="exampleInputEmail" placeholder="<?php echo e($paket->nama_owner); ?>" disabled="">
              </div>
            </div>
            <div class="form-group row">
              <div class="col-sm-6 mb-3 mb-sm-0">
                <label>Tempat : </label>
                <input type="password" class="form-control form-control-user" id="exampleInputPassword" placeholder="<?php echo e($paket->tempat); ?>" disabled="">
              </div>
              <div class="col-sm-6">
                <label>harga : </label>
                <input type="password" class="form-control form-control-user" id="exampleRepeatPassword" placeholder="<?php echo e($paket->harga); ?>" disabled="">
              </div>
            </div>
            <a href="<?php echo e(url('/paket')); ?>" class="btn btn-primary btn-user btn-block">
              Back
            </a>

            
            
          </form>
          

        </div>
      </div>
    </div>
  </div>
</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\wo\resources\views/paket/show.blade.php ENDPATH**/ ?>