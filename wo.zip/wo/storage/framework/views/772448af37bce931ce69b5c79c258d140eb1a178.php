<?php $__env->startSection('content'); ?>
<?php
$ar_judul = ['No','Nama','Catering','Dekorasi','Rias','Tempat','Harga','Owner','Foto','Action'];
$no = 1;  
?>

<a href="<?php echo e(route('paket.create')); ?>" class="btn btn-sm btn-primary">Tambah</a>

<a href="/paket/export" class="btn btn-sm btn-primary">Export Excel</a>
<a href="/paket/exportPdf" class="btn btn-sm btn-primary">Export PDF</a>

<br/>


<!-- DataTales Example -->
<div class="card shadow mb-4">
  <div class="card-header py-3">
    <h6 class="m-0 font-weight-bold text-primary">Data Paket</h6>
  </div>
  <div class="card-body">
    <div class="table-responsive">
      <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
        <thead>
          <tr>
            <?php $__currentLoopData = $ar_judul; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jdl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <th><?php echo e($jdl); ?></th>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
          </tr>
        </thead>
        <tbody>

          <?php
          $no = 1;  
          ?>
          <?php $__currentLoopData = $ar_paket; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

          <tr>
            <td><?php echo e($no++); ?></td>
            <td><?php echo e($paket->nama); ?></td>
            <td><?php echo e($paket->catering); ?></td>
            <td><?php echo e($paket->dekorasi); ?></td>
            <td><?php echo e($paket->rias); ?></td>
            <td><?php echo e($paket->tempat); ?></td>
            <td><?php echo e($paket->harga); ?></td>
            <td><?php echo e($paket->nama_owner); ?></td>
            <td><img src="<?php echo e(asset('img')); ?>/<?php echo e($paket->foto); ?>" width="40%" /> </td>



            
            <td width="15%"> 
              <form method="POST" action="<?php echo e(route('paket.destroy',$paket->id)); ?>" >

              <a href="<?php echo e(route('paket.show',$paket->id)); ?>">
              <i class="fas fa-eye"></i>
              </a>
              &nbsp;&nbsp;

              <a href="<?php echo e(route('paket.edit',$paket->id)); ?>">
              <i class="fas fa-pencil-alt"></i> 
              </a>

              <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit" class="btn-btn-link" onclick="return confirm('Yakin dihapus?')">
                <i class="fas fa-trash-alt"></i>
                </button>
              </form>






            </td>
          </tr>

          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 

        </tbody>
      </table>
    </div>
  </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\wo\resources\views/paket/index.blade.php ENDPATH**/ ?>