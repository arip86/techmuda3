<?php
$ar_judul = ['No','Nama','Catering','Dekorasi','Rias','Tempat','Harga','Owner'];
$no = 1;
?>

<div class="card-body">
    <div class="table-responsive">
<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0" border="1">
	<thead>
		<tr>
            <?php $__currentLoopData = $ar_judul; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jdl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <th><?php echo e($jdl); ?></th>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tr>
	</thead>
	<tbody>
		<?php
          $no = 1;  
          ?>
          <?php $__currentLoopData = $paket; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pak): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
			     <td><?php echo e($no++); ?></td>
            <td><?php echo e($pak->nama); ?></td>
            <td><?php echo e($pak->catering); ?></td>
            <td><?php echo e($pak->dekorasi); ?></td>
            <td><?php echo e($pak->rias); ?></td>
            <td><?php echo e($pak->tempat); ?></td>
            <td><?php echo e($pak->harga); ?></td>
            <td><?php echo e($pak->nama_owner); ?></td>
          </tr>
            

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</tbody>
</table>
</div>
</div><?php /**PATH C:\xampp\htdocs\wo\resources\views/export/paketpdf.blade.php ENDPATH**/ ?>