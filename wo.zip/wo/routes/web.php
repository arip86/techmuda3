<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/




/*
Route::get('/paket', 'PaketController@index');
//ini untuk routing
Route::post('/paket/create','PaketController@create');
//ini untuk edit
Route::get('/paket/{id}/edit','PaketController@edit');
//ini untuk update
Route::post('/paket/{id}/update','PaketController@update');
//ini untuk delete
Route::get('/paket/{id}/delete','PaketController@delete');
*/

Route::get('/', function () {
    return view('/layouts/tampilandepan');
});





//untuk login
Route::get('/login', 'AuthController@login')->name('login');
Route::post('/postlogin', 'AuthController@postlogin');
Route::get('/logout', 'AuthController@logout');


//otentikasi login
Route::group(['middleware' => 'auth'], function(){






Route::get('/about', function () {
    return view('/layouts/about');
});


Route::get('/paket/export/', 'PaketController@export');
Route::get('/paket/exportPdf/', 'PaketController@exportPdf');


Route::resource('paket','PaketController');

});



