<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class pegawaimodel extends Model
{
    //mapping table
    protected $table = 'pegawai';
}
