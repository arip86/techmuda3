<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class customermodel extends Model
{
    //mapping table
    protected $table = 'customer';
}
