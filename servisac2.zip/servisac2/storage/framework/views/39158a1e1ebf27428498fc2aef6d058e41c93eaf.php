 
 <?php $__env->startSection('content'); ?>

<?php $__currentLoopData = $coba; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>




       
  <div class="col-sm-6">
    <div class="card">
      <div class="card-body">
        <h5 class="card-title">Nama : <?php echo e($cm->namacustomer); ?></h5>
        <p class="card-text">Jenis kelamin : <?php echo e($cm->gender); ?></p>
        <p class="card-text">Alamat : <?php echo e($cm->alamat); ?></p>
        <p class="card-text">Kota : <?php echo e($cm->kota); ?></p>
        <p class="card-text">No Handphone : <?php echo e($cm->hp); ?></p>
      
                  <a href="<?php echo e(url('customermodel')); ?>" class="btn btn-facebook btn-user btn-block">
                  <i class="fas fa-sign-out-alt"></i> &nbsp;&nbsp; KEMBALI
                </a>
              
      </div>
    </div>
  </div>
 

      


<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\servisac\resources\views/customer/show.blade.php ENDPATH**/ ?>