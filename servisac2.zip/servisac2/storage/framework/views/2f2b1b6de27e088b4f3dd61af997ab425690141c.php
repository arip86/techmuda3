<!-- pengembangannya ada pada folder layout>> master.blade.php -->

<?php $__env->startSection('content'); ?>
<!-- ini berfungsi memasukan isi pada master blade -->


  <div class="row">


<div class="col-6">
        <h1>Data customer</h1> <br>

<!-- Button trigger modal -->
              <button type="button" class="btn btn-info" data-toggle="modal" data-target="#exampleModal">
                Tambahkan customer
              </button>
              <br>
              <br>
<!-- Modal -->
      <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
          <div class="modal-dialog" role="document">
              <div class="modal-content">
                  <div class="modal-header">
                          <h5 class="modal-title" id="exampleModalLabel">Input Data Customer</h5>
                          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                          </button>
                  </div>

<!-- Form -->
  <div class="modal-body">


    <form action="/customermodel/create" method="get">
            <?php echo e(csrf_field()); ?>


      <!-- penamaanya harus sesuai database -->
            <div class="form-group">
                  <label for="exampleInputEmail1">
                  Nama customer
                  </label>

                  <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="namacustomer">
            </div>
                
            <div class="form-group">
                  <label for="exampleFormControlSelect1">Jenis kelamin
                  </label>
                  <select name="gender" class="form-control" id="exampleFormControlSelect1">
                      <option value="L">---Pilih Jenis Kelamin---</option>
                      <option value="L">Laki-Laki</option>
                      <option value="P">Perempuan</option>
                  </select>
            </div>
                 
            <div class="form-group">
                  <label >Alamat</label><br>
                  <textarea name="alamat" class="form-control" rows="3"></textarea>
            </div>

            <div class="form-group">
                  <label for="exampleInputEmail1">Kota</label>
                  <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="kota">
            </div>

            <div class="form-group">
                  <label for="exampleInputEmail1">Nomor Handphone</label>
                  <input type="number" class="form-control" name="hp">
            </div>
                
                
                
               
            <div class="modal-footer">
                      <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                      <button type="submit" class="btn btn-primary">Submit</button>

            </div>

    </form>

</div>
          
          </div>
      </div>
  </div>
</div>





<table class="table table-striped table-light table-hover">
          <br>
          <br>
          <tr class="table-primary" >
             <th>No</th>
            <th>Nama Customer</th>
            <th>Jenis Kelamin</th>
            <th>Alamat</th>
            <th>Kota</th>
            <th>No. Handphone</th>
           <th></th>
          </tr>


           <?php
            $no=1;
            ?>
          <?php $__currentLoopData = $coba; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

          <tr >

            <td><?php echo e($no++); ?></td>
            <td><?php echo e($customer->namacustomer); ?></td>
            <td><?php echo e($customer->gender); ?></td>
            <td><?php echo e($customer->alamat); ?></td>
            <td><?php echo e($customer->kota); ?></td>
            <td><?php echo e($customer->hp); ?></td>
              <td>
           <a href="<?php echo e(route('customermodel.show',$customer->id)); ?>" color="red"><i class="far fa-eye" style="color:blue;" ></i></a>&nbsp;&nbsp;
            <a href="/customermodel/<?php echo e($customer->id); ?>/edit"> <i class="fas fa-pen" style="color:green;"></i></a> 
            &nbsp;&nbsp;
            <a href="/customermodel/<?php echo e($customer->id); ?>/delete" onclick="return confirm('Apakah anda yakin ingin di hapus?')"> <i class="fas fa-trash-alt" style="color:red;"></i></a>

          </td>

          </tr>
          <!-- {{}} >> arti 2 penutup kurung kurawal ini untuk memanggik data di database sedang kurung kurawal 1 {} itu untuk memanggil data,gambar,dll -->

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!-- fungsi @ itu artinya hampir sama kaya fungsi php jadi kaya di peringkas gitu pemanggilannya -->



</table>

<!-- index.blade.php adalah untuk tampilan dari function view -->

</div>
  

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\servisac\resources\views/customer/tampilancm.blade.php ENDPATH**/ ?>