<!-- pengembangannya ada pada folder layout>> master.blade.php -->

<?php $__env->startSection('isi'); ?>
<!-- ini berfungsi memasukan isi pada master blade -->


<h1>Edit data pegawai</h1>
  <div class="row">
  <div class="col-lg-12">


<form action="/pegawaimodel/<?php echo e($pegawai->id); ?>/update" method="POST">
            <?php echo e(csrf_field()); ?>


      <!-- penamaanya harus sesuai database -->
            <div class="form-group">
                  <label for="exampleInputEmail1">
                  Nama pegawai
                  </label>

                  <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="namapegawai" value="<?php echo e($pegawai->namapegawai); ?>">
            </div>
                
            <div class="form-group">
                  <label for="exampleFormControlSelect1">Jenis kelamin
                  </label>
                  <select name="gender" class="form-control" id="exampleFormControlSelect1">
                      <option value="L">---Pilih Jenis Kelamin---</option>

                     	<option value="L" <?php if($pegawai->gender == 'L'): ?> selected <?php endif; ?>>Laki-Laki</option>
                      
                      <option value="P" <?php if($pegawai->gender == 'P'): ?> selected <?php endif; ?>>Perempuan</option>
                  </select>
            </div>
                 
            <div class="form-group">
                  <label >Alamat</label><br>
                  <textarea name="alamat" class="form-control" rows="3"><?php echo e($pegawai->alamat); ?></textarea>
            </div>

            <div class="form-group">
                  <label for="exampleInputEmail1">Kota</label>
                  <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="kota" value="<?php echo e($pegawai->kota); ?>">
            </div>

            <div class="form-group">
                  <label>Nomor Handphone</label>
                  <input type="number" class="form-control" name="hp" value="<?php echo e($pegawai->hp); ?>">
            </div>
                
                
                
               
            <div class="modal-footer">
                      
                      <button type="submit" class="btn btn-primary">Submit</button>

            </div>

    </form>
</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\servisac\resources\views/pegawai/edit.blade.php ENDPATH**/ ?>