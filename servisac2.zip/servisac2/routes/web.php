<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    // return view('welcome');
    return view('layouts.home'); 
    // atau return view('/layouts/index');
});

Route::get('/home', function () {
    return view('layouts.home'); 
});

Route::get('/about', function () {
    return view('layouts.about'); 
});


/*CARA PERTAMA*/

		Route::resource('customermodel','customercontroller');
		// kalau mau namanya gamau sesuai struktur atau maunya bebas pakai route nya yg kaya gini Route::get('customermodel','customercontroller@namafungsinya');

		Route::resource('pegawaimodel','pegawaicontroller');

		Route::get('/clear-cache',function(){
			Artisan::call('cache:clear');
			return "cache is cleared";
		});

	// Route::post('/customermodel/{id}/create','customercontroller@create');
/*CARA KEDUA*/

		/*AKTIFIN YANG INI KALAU MAU PAKAI YANG LAMA*/

		// Route::get('/', function () {
		//     return view('welcome');
		// });


		// /* PEGAWAI */

		// 	Route::get('/pegawaimodellama','pegawaicontrollelamar@tampilan');
			
			/* untuk menghubungkan model dan controller */

		
		// 	Route::post('/pegawaimodellama/create','pegawaicontrollerlama@add');
		// 	Route::get('/pegawaimodellama/{id}/edit','pegawaicontrollerlama@ubah');
		// 	Route::post('/pegawaimodellama/{id}/update','pegawaicontrollerlama@update');
		// 	Route::get('/pegawaimodellama/{id}/delete','pegawaicontrollerlama@hapus');




		// /* CUSTOMER*/


		//BAGIAN YANG @ ADALAH FUNGSI DARI CONTROLLER
		// 	Route::get('/customermodellama','customercontrollerlama@tampilan');


		// 	// ini untuk create
		// 	Route::post('/customermodellama/create','customercontrollerlama@create');
		// 	Route::get('/customermodellama/{id}/edit','customercontrollerlama@edit');
		// 	Route::post('/customermodellama/{id}/update','customercontrollerlama@update');
		// 	Route::get('/customermodellama/{id}/delete','customercontrollerlama@delete');
